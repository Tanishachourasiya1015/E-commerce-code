document.getElementById('checkout-form').onsubmit = function(event) {
    event.preventDefault(); // Prevent default form submission

    // Retrieve user input
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const cardNumber = document.getElementById('card-number').value;
    const expiry = document.getElementById('expiry').value;
    const cvv = document.getElementById('cvv').value;

    // Simple validation
    if (!validateCard(cardNumber)) {
        showMessage("Invalid card number. Please enter a valid 16-digit card number.", true);
        return;
    }

    // Simulate payment processing
    const isSuccess = Math.random() > 0.5; // 50% chance of success

    if (isSuccess) {
        showMessage(`Payment successful! Thank you, ${name}.`, false);
        document.getElementById('success-message').style.display = 'block';
        document.getElementById('error-message').style.display = 'none';
    } else {
        showMessage("Payment failed. Please try again.", true);
        document.getElementById('error-message').style.display = 'block';
        document.getElementById('success-message').style.display = 'none';
    }
};

function showMessage(message, isError) {
    const responseMessage = isError ? document.getElementById('error-message') : document.getElementById('success-message');
    responseMessage.textContent = message;
}

function validateCard(cardNumber) {
    // Simple validation for 16-digit card numbers
    return /^\d{16}$/.test(cardNumber);
}